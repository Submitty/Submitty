function screenshot_plot()
  figure('Visible','off')
  x=-10:0.1:10;
  y=sqrt((36-x.^2)/9);
  plot(x,y)
  saveas(gcf,'student1.png','png')
  quit
end
