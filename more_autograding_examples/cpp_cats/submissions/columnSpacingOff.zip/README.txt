print(out, cats)
  regular print out where the output is what is expected

print_extraLines(out, cats)
  print out with everything correct except that every line has an extra
  newline printed at the end

print_extraSpaces(out, cats)
  print out with everything correct except that every line has an extra
  space printed out at the end

print_lineOrder(out, cats)
  print out where the information is correctly spaced but the line 
  order is wrong (not sorted alphabetically by cat breed)

print_frontSpacing(out, cats)
  print out where everything is correct except that the spacing
  in front of the first column is wrong

print_columnSpacing(out, cats)
  print out where everything is correct except that the spacing
  between the first and second column is wrong

print_spacingOff(out, cats)
  print out where all information is correct and correctly sorted
  but all the spacing is off


AUTOGRADING RESULTS: 5 pts README & compilation, 4 pts for each of 4 test cases
print(out, cats)
  21/21     All 4 versions of Myers Diff gave full points.
  No problem. 

print_extraLines(out, cats)
  13/21     All four versions of Myers Diff gave half of the points (2/4) for an
            extra newline at the end of every line.
  myersDiffbyLinebyChar: expected given how picky the line by char is
  myersDiffbyLinebyWord: Kind of surprising because I thought the diff would be based
                         on the words there, not the spacing
  myersDiffbyLine:  expected given that there are more lines than the expected solution
  myersDiffbyLineNoWhite: Surprising. Expected to get full points since I thought that
                          no white would mean that it would ignore the extra newlines


print_extraSpaces(out, cats)
  13/21     myersDiffbyLinebyChar and myersDiffbyLine gave no points
            myersDiffbyLinebyWord and myersDiffbyLineNo white gave full points
  myersDiffbyLinebyChar: expected. Everything is shown as red with the extra space
            highlighted in pale yellow (a bit hard to see)
  myersDiffbyLinebyWord: expected since it's supposed to compare by word
  myersDiffbyLine: kind of unexpected. Expected to get some points since the lines
            only had extra spaces at the end of the line. Also, diff comparison
            didn't seem to show the extra space in yellow at the end of the lines
            (just a block of red)
  myersDiffbyLineNoWhite: expected since it's supposed to ignore whitespace
  *note: would like myersDiffbyChar and myersDiffbyLine to give at least 1 or 2 points
         since the only thing wrong is one extra space at the end of the lines


print_lineOrder(out, cats)
  9/21      All four versions of Myers Diff gave 1 point for having the line order
            wrong
  myersDiffbyLinebyChar: expected
  myersDiffbyLinebyWord: kind of expected
  myersDiffbyLine: kind of expected 1 or 2 more points since the only thing wrong is the
             line order
  myersDiffbyLineNoWhite: expected
  *note: in a previous submission with line order off all test cases had given 2 points
         so points off kind of based on just how off the ordering is


print_frontSpacing(out, cats)
  15/21      myersDiffbyLinebyChar and myersDiffbyLine gave 1 point
             myersDiffbyLinebyWord and myersDiffbyLineNo white gave full points
  myersDiffbyLinebyChar: expected
  myersDiffbyLinebyWord: expected since it compares by word
  myesrDiffbyLine: kind of expected at this point in testing, still not satisfied with
             result though since the only thing wrong is a little bit of spacing
             and only the lines (not the spaces) are highlighted
  myersDiffbyLineNoWhite: expected since it ignores whitespace differences


print_columnSpacing(out, cats)
  
  myersDiffbyLinebyChar:
  myersDiffbyLinebyWord
  myersDiffbyLine:
  myersDiffbyLineNoWhite:

print_spacingOff(out, cats)
  print out where all information is correct and correctly sorted
  but all the spacing is off




CORRECT OUTPUT:

Abyssinian
     Average Lifespan: 8
     Average Weight:   12
     Interesting Fact:  loves heights
American_Curl
     Average Lifespan: 7.5
     Average Weight:   14
     Interesting Fact:  ears are curled backward
American_Shorthair
     Average Lifespan: 9.5
     Average Weight:   17.5
     Interesting Fact:  recognized as a breed in 1906
Balinese
     Average Lifespan: 7.5
     Average Weight:   12
     Interesting Fact:  named for the dancers on the Indonesian island of Bali
Bombay
     Average Lifespan: 8.5
     Average Weight:   14
     Interesting Fact:  named for a port city in India
Chinese_Li_Huea
     Average Lifespan: 10.5
     Average Weight:   12.5
     Interesting Fact:  is a natural breed
Exotic
     Average Lifespan: 9.5
     Average Weight:   11.5
     Interesting Fact:  nicknamed "the lazy man's Persian"
Himalayan
     Average Lifespan: 41
     Average Weight:   12
     Interesting Fact:  developed by crossing Persians with Siamese
Japanese_Bobtail
     Average Lifespan: 8
     Average Weight:   12
     Interesting Fact:  tricolor coats are a symbol of good luck
Ragdoll_Cats
     Average Lifespan: 12.5
     Average Weight:   14.5
     Interesting Fact:  first developed in 1960s
Siberian
     Average Lifespan: 12.5
     Average Weight:   13
     Interesting Fact:  appear in Russian folktales
Singapura
     Average Lifespan: 6
     Average Weight:   13
     Interesting Fact:  in 1990 became Singapore's travel mascot
Snowshoe
     Average Lifespan: 10.5
     Average Weight:   16.5
     Interesting Fact:  developed in mid-20th century
