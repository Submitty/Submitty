SELECT count(*) 
FROM contributors
WHERE endyear IS NULL;