function screenshot_plot()
  figure('Visible','off')
  disp('Hey there!')
  plot(1:100)
  saveas(gcf,'student1.png','png')
  quit
end
