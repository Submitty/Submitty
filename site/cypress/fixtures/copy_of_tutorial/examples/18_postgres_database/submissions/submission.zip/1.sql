SELECT firstname, lastname, startyear
FROM contributors
WHERE startyear = 2016;