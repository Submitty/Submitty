print(out, cats)
  regular print out where the output is what is expected

print_extraLines(out, cats)
  print out with everything correct except that every line has an extra
  newline printed at the end

print_extraSpaces(out, cats)
  print out with everything correct except that every line has an extra
  space printed out at the end

print_lineOrder(out, cats)
  print out where the information is correctly spaced but the line 
  order is wrong (not sorted alphabetically by cat breed)

print_frontSpacing(out, cats)
  print out where everything is correct except that the spacing
  in front of the first column is wrong

print_columnSpacing(out, cats)
  print out where everything is correct except that the spacing
  between the first and second column is wrong

print_spacingOff(out, cats)
  print out where all information is correct and correctly sorted
  but all the spacing is off


AUTOGRADING RESULTS:
print(out, cats)
  No problem. All 4 versions of Myers Diff gave full points.

print_extraLines(out, cats)
  All four versions of Myers Diff gave half of the points (2/4) for an extra
  newline at the end of every line. I suppose this is fair although given
  the name of "myersDiffbyLineNoWhite" I had expected that one to give full
  points because I thought it would get rid of the whitespace before running
  the diff algorithm.

print_extraSpaces(out, cats)
  print out with everything correct except that every line has an extra
  space printed out at the end

print_lineOrder(out, cats)
  print out where the information is correctly spaced but the line 
  order is wrong (not sorted alphabetically by cat breed)

print_frontSpacing(out, cats)
  print out where everything is correct except that the spacing
  in front of the first column is wrong

print_columnSpacing(out, cats)
  print out where everything is correct except that the spacing
  between the first and second column is wrong

print_spacingOff(out, cats)
  print out where all information is correct and correctly sorted
  but all the spacing is off




CORRECT OUTPUT:

Abyssinian
     Average Lifespan: 8
     Average Weight:   12
     Interesting Fact:  loves heights
American_Curl
     Average Lifespan: 7.5
     Average Weight:   14
     Interesting Fact:  ears are curled backward
American_Shorthair
     Average Lifespan: 9.5
     Average Weight:   17.5
     Interesting Fact:  recognized as a breed in 1906
Balinese
     Average Lifespan: 7.5
     Average Weight:   12
     Interesting Fact:  named for the dancers on the Indonesian island of Bali
Bombay
     Average Lifespan: 8.5
     Average Weight:   14
     Interesting Fact:  named for a port city in India
Chinese_Li_Huea
     Average Lifespan: 10.5
     Average Weight:   12.5
     Interesting Fact:  is a natural breed
Exotic
     Average Lifespan: 9.5
     Average Weight:   11.5
     Interesting Fact:  nicknamed "the lazy man's Persian"
Himalayan
     Average Lifespan: 41
     Average Weight:   12
     Interesting Fact:  developed by crossing Persians with Siamese
Japanese_Bobtail
     Average Lifespan: 8
     Average Weight:   12
     Interesting Fact:  tricolor coats are a symbol of good luck
Ragdoll_Cats
     Average Lifespan: 12.5
     Average Weight:   14.5
     Interesting Fact:  first developed in 1960s
Siberian
     Average Lifespan: 12.5
     Average Weight:   13
     Interesting Fact:  appear in Russian folktales
Singapura
     Average Lifespan: 6
     Average Weight:   13
     Interesting Fact:  in 1990 became Singapore's travel mascot
Snowshoe
     Average Lifespan: 10.5
     Average Weight:   16.5
     Interesting Fact:  developed in mid-20th century
